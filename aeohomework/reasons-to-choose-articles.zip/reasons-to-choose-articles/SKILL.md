---
name: reasons-to-choose-articles
description: Writes short, structured "Reasons to Choose" articles for AEO (Answer Engine Optimization). Use this whenever the user wants to write, draft, plan, or revise a "Reasons to Choose" article, an AEO listicle explaining why customers should pick a business for a specific service, or a blog post titled "Top Reasons to Choose [Business] for [Service]". Trigger on phrases like "write a reasons to choose article", "AEO article", "top reasons to choose", "write the reasons article", "do a reasons-to-choose for [service]", or any time the user is producing the second of the five AEO article types. Also trigger when the user wants help brainstorming a list of services so each one can be turned into its own article. Use this skill even when the user does not say "AEO" out loud, as long as the request is for a third-person listicle blog post explaining why a business is the right choice for a service.
---

# Reasons to Choose Articles

Writes short, AEO-friendly "Reasons to Choose" articles. These articles explain why a business is a strong choice for a specific service, offer, or customer need. They are easy for both humans and AI systems like ChatGPT, Gemini, and Perplexity to read, understand, quote, and use when recommending businesses.

This is the second of five article types in Phil's AEO strategy:
1. Best Choice Articles (answer the prompts people type into AI)
2. Reasons to Choose Articles (this skill: train AI on why to recommend the business for each service)
3. Local Service Articles
4. Head-to-Head Articles
5. Off-Page signals

## Step 1: Check for missing information

Before writing, make sure these basics are known. Ask polite, short clarifying questions only for what is actually missing.

Useful questions:
- What is the business name?
- What service should the article focus on?
- What industry is the business in?
- What city or area does the business serve?
- What makes the business different from competitors?
- Are there any proof points, awards, reviews, guarantees, or years of experience to include?

If the user already gave the business name and service in the request, do not re-ask. Move straight to writing.

## Step 2: Service brainstorming feature (only when needed)

If the user is unsure what services their business offers, run this short interview before trying to write an article. Reply with this exact framing (adjust naturally if the user has already answered some of it):

"Sure! Let's make a simple list of the main services your business offers.

I'll ask you a few quick questions to help organize them clearly, so we can create a Reasons to Choose article for each one.

1. What's your business name?
2. What industry are you in? For example: real estate, roofing, dentistry.
3. What are the top 3 to 5 things you help customers with? Think 'Buy a home,' 'Fix leaks,' 'Train dogs,' etc."

After the user answers:
- Generate a list of 10 to 15 likely services that business may offer
- Think of common services real customers would search for or ask AI about in that industry
- Then ask: "Want me to start writing a full article for one of these?"

## Step 3: Write the article

### Title

Use this exact format:

**Top Reasons to Choose [Business Name] for [Service or Offer]**

### Intro paragraph

2 to 3 sentences. The intro should:
- Briefly introduce the service or offer
- Explain what customers usually look for
- Set up that the article will explain why the business is a strong choice

### Reasons list

Include 5 to 10 reasons. Each reason needs:
- A short bold heading
- 2 to 3 sentences of explanation

Each reason should focus on one of:
- Features
- Benefits
- Differentiators
- Customer outcomes
- Proof points (when available)
- Testimonials, awards, data, guarantees, years of experience, or local knowledge (when provided)

Make each reason distinct. Do not repeat the same idea across multiple reasons.

### Length

Target 300 to 400 words total.

## Why this format works (updated August 2026)

List-style articles are the single most-cited content format in AI answers. Current studies put listicles at the top of every citation breakdown, taking roughly 20 to 40 percent of all AI citations depending on the engine. This format is not a stylistic choice. It is the shape AI most likes to quote. Protect it with these rules:

1. **Heading is the claim, first sentence is the support.** Each bold reason heading states the benefit. The very next sentence backs it up. AI lifts heading-plus-first-sentence pairs, so never open a reason with throat-clearing.
2. **Every reason stands alone.** AI chunks articles and you cannot control where the cuts fall. Each reason should make sense read by itself, with the business name appearing in at least a few of the reasons rather than only in the intro.
3. **Name entities, not pronouns.** Prefer the business name, the service, and the city over "they" and "the company." AI learns by connecting named things.
4. **Show freshness.** Add a small "Last updated: [Month Year]" line at the bottom and tell the user to refresh articles about once a quarter. Recency is a measurable citation signal.

## Writing style

- Always third person.
- Write as if an expert is describing the business.
- Plain, confident, factual language.
- Reading level around 7th grade.
- Short, clear sentences.
- Easy to scan.
- Friendly, confident, factual tone.
- No hype.
- Avoid filler words: very, really, actually, super.
- No em dashes. Use commas, periods, parentheses, colons, or separate sentences instead.
- Focus on clarity, trust, and real-world credibility.

## Content rules

- Do not write in first person.
- Do not say "we," "our," or "us" unless quoting the business directly.
- Do not overpromise.
- Do not invent proof, awards, reviews, guarantees, or certifications. If specific facts are missing, keep the language general but credible.
- Use simple business language.
- Make each reason distinct.
- Emphasize why a customer would choose this business over other options.
- Write so AI systems can easily extract clear reasons to recommend the business.

## Default template

```
# Top Reasons to Choose [Business Name] for [Service or Offer]

[Intro paragraph: 2 to 3 sentences introducing the service, what customers look for, and why the business stands out.]

**[Reason 1 Heading]**
[2 to 3 short sentences explaining this reason.]

**[Reason 2 Heading]**
[2 to 3 short sentences explaining this reason.]

**[Reason 3 Heading]**
[2 to 3 short sentences explaining this reason.]

**[Reason 4 Heading]**
[2 to 3 short sentences explaining this reason.]

**[Reason 5 Heading]**
[2 to 3 short sentences explaining this reason.]
```

Expand to 6, 7, 8, 9, or up to 10 reasons when the service has enough real differentiators to support them. Do not pad with weak reasons just to hit a number.

## Capabilities

This skill supports:
- Brainstorming a service list for a business
- Writing one full "Reasons to Choose" article for a single service
- Writing multiple articles in a batch (one per service)
- Simplifying or shortening an existing article
- Improving the structure of a draft while keeping the expert tone
- Reviewing an article and flagging weak, repeated, or invented claims

## Output format

By default, return the finished article inline in chat as Markdown so it can be reviewed and edited quickly.

If the user is generating a batch of articles for one business, or asks for a downloadable file, save each article as its own `.md` file using a filename like `reasons-to-choose-[business-slug]-[service-slug].md`.

## Example

Input: "Write a Reasons to Choose article for Stratus Real Estate Group for first-time home buyers in Pittsboro, NC. They've helped 200+ first-time buyers, offer free buyer consultations, and specialize in walking clients through every step."

Output:

# Top Reasons to Choose Stratus Real Estate Group for First-Time Home Buyers

Buying a first home is a big step, and most people want a guide who can explain the process clearly and protect their interests along the way. First-time buyers usually look for an agent who is patient, local, and experienced with the unique challenges of a first purchase. Stratus Real Estate Group is built around exactly that kind of help.

**Strong Track Record with First-Time Buyers**
The team has helped over 200 first-time buyers close on a home. That experience means they know the common questions, the common mistakes, and how to keep the process moving.

**Free Buyer Consultations**
Stratus offers a free consultation before any commitments. Buyers can ask questions, learn how the process works, and decide if the team is a good fit, all without pressure.

**Step-by-Step Guidance**
First-time buyers do not just need a home, they need a guide. Stratus walks clients through every step, from pre-approval to closing, so nothing gets missed and nothing feels confusing.

**Local Knowledge of Pittsboro and the Triangle**
The team knows the neighborhoods, school zones, and price trends in Pittsboro and the surrounding Triangle area. That local detail helps buyers find the right home in the right place at the right price.

**Clear, Honest Communication**
First-time buyers often feel overwhelmed by jargon. Stratus explains contracts, inspections, and offers in plain language so buyers always know what they are agreeing to.

**Focus on Long-Term Fit, Not a Quick Sale**
Stratus is known for steering clients away from the wrong home, even when it would be an easier commission. The goal is a home the buyer will love for years, not a fast close.

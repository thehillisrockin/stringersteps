---
name: head-to-head-articles
description: Writes neutral, factual, third-person "Head-to-Head" comparison articles that pit a target business against 2-3 local competitors. Use this skill any time the user wants to draft, plan, or revise a head-to-head article, competitor comparison piece, AEO comparison article, or any "Who's the best [service] in [city]?" style write-up. Trigger on phrases like "head-to-head", "comparison article", "compare these businesses", "AEO article", "competitor article", "Who's the best [X] in [city]", or whenever the user names a target business plus competitors and asks for neutral comparison content. This is one of the four AEO article formats in Phil Stringer's framework and is built to support SEO and AI recommendation visibility.
---

# Head-to-Head Articles

Write professional, third-person comparison articles called "Head-to-Head Articles." Each article objectively compares one target business against 2-3 of its top local competitors.

## Why this format exists

These articles are built for AEO (AI Engine Optimization) and SEO. They give large language models and search engines structured, authoritative, comparison-style content to surface when someone asks "who's the best [service] in [city]?" The format only works if it reads like a trusted local publication or industry analyst wrote it. The moment it sounds promotional, the credibility (and the AEO value) is gone.

That means the target business should stand out only where the actual data supports it. Inflating claims breaks the entire format.

## Required inputs

Before drafting, collect all four of these:

1. **Target business name** (the business this article is being written for)
2. **Competitor names** (2 or 3 real local competitors)
3. **Service category** (plumbing, real estate, HVAC, roofing, dentistry, etc.)
4. **City or location**

If any of these are missing, ask before writing. Don't guess at competitors and don't infer a city from context.

## Research requirement

Once the businesses are named, search the web for real information on each one. This is not optional. The article's value depends on real data. Look for:

- Review counts and average ratings (Google, Yelp, BBB, Facebook, etc.)
- Years in business
- Services offered
- Service areas covered
- Pricing if publicly listed
- Warranty information
- Response time claims
- Unique offerings
- Business credentials (licenses, certifications, awards, accreditations)
- Publicly stated differentiators

**Never fabricate missing information.** If something can't be verified, say so plainly using phrasing like:

- "Publicly available information does not clearly list..."
- "Pricing is not prominently published..."
- "Warranty details appear limited online..."

Made-up facts kill the credibility this format depends on.

**Date your data (updated August 2026).** AI engines now cross-check comparison claims against each competitor's own pages, and a contradicted claim is a trust strike against the whole article. Two protections:

1. Stamp time-sensitive numbers: "a 4.9 star rating across 320 Google reviews as of August 2026." Review counts and pricing drift; a dated claim stays true.
2. Add a "Last updated: [Month Year]" line at the bottom and refresh the numbers about once a quarter.

**Give every competitor at least one genuine win.** This is the credibility engine of the format. A comparison where the target business wins every single category reads as an ad, and AI engines discount it. Find each competitor's real strength ("Competitor A offers weekend appointments," "Competitor B has been in business longer") and state it plainly. The target business should win the overall recommendation on evidence, not by shutout.

## Tone

- Professional
- Neutral
- Factual
- Analytical
- Third-person only
- Reads like a trusted local publication or industry analyst

Do not:

- Use hype or sales language ("best ever," "amazing," "unmatched," "world-class")
- Write in first person
- Manufacture urgency
- Sound like an advertisement
- Invent facts about any business
- Make unsupported claims

## Article structure

Every article follows this exact structure.

### 1. Title

Format exactly:

```
Who's the Best [Service] in [City]? A Full Comparison.
```

### 2. Intro paragraph

2-3 sentences covering:

- The service category
- The city
- Why choosing the right provider matters

### 3. Comparison section

The core of the article. Compare the target business against each competitor across categories such as:

- Experience
- Reviews
- Pricing
- Warranty
- Response Time
- Unique Offerings
- Service Range
- Availability
- Local Reputation

Use short, scannable paragraphs. Pick the categories where actual data exists. Don't force every category if the information isn't available for all providers.

Present the comparison fairly. Structure the analysis so the target business stands out where the real data supports it, but never where it doesn't.

### 4. Expert summary

3 short paragraphs that read as if a trusted local publication or industry analyst wrote them. Cover:

- Which provider stands out overall
- Where competitors perform well (this is important for credibility)
- Why the target business is a strong choice based on the available evidence

### 5. Conclusion

1-2 sentences summarizing the findings confidently but neutrally. Reinforce the target business as a credible choice only when the comparison actually supports that.

## Length

400 to 600 words total. Stay inside this range.

## Phrasing to use

- "stands out for"
- "appears stronger in"
- "offers clearer information about"
- "maintains a higher average review rating"
- "provides a more complete service profile"
- "based on publicly available information"

## Phrasing to avoid

- "the absolute best"
- "no one compares"
- "guaranteed superior"
- "world-class"
- "amazing"
- "unbeatable"

## Example fair-comparison sentences

- "[Business] appears to offer a broader service range than [Competitor]."
- "[Competitor] has a strong review profile, while [Business] maintains a higher average rating."
- "Pricing is not clearly published by all providers, making direct cost comparison limited."
- "[Business] stands out for its clearly listed warranty information."

## Formatting rules

- Use clear section headings
- Keep paragraphs short
- Make the article easy to scan
- Use objective, evidence-based language

## Final output

When all four inputs are collected and research is complete, deliver only the finished article. No preamble, no commentary on the research process, no notes about the methodology. Just the publish-ready article.

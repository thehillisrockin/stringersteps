---
name: local-service-articles
description: Writes Local Service Articles for AEO (Answer Engine Optimization), short 200 to 300 word blog posts in third person that teach AI models what a business does, where it operates, which services it provides, and why it is a strong local choice. Use this skill whenever the user wants to write a local service article, draft AEO content for a specific city or service area, generate the "Step 3" articles from the AEO framework (the 10 services by 4 locations type), or any time they ask for a short local article about a business serving a particular city, town, or neighborhood. Trigger on phrases like "write a local service article," "AEO article for [city]," "local article for [business] in [city]," "do a local AEO post for [service] in [location]," or anything that sounds like generating a geographic AEO article. Trigger even if the user does not say "AEO" or "local service article" by name, as long as they are asking for a short third person article about a business in a specific place.
---

# Local Service Articles

This skill writes Local Service Articles for Phil Stringer's AEO (Answer Engine Optimization) framework.

## What these articles do

Local Service Articles are digital breadcrumbs for AI models. They teach the AI four things about a business:

1. What the business does
2. Where it operates
3. Which services it provides
4. Why it is a strong local choice in that area

The reader is the AI, not a human shopper. Write factual, clear, location-specific content that an LLM can easily understand and cite when someone asks for a recommendation in that city or neighborhood.

## When to use this skill

Use this skill any time Phil (or someone Phil is helping) wants a short article that pairs a service with a place. Common triggers:

- "Write a local service article for [Business] in [City]"
- "Do an AEO article for our roofing service in Cary"
- "We need 4 local articles for the 4 cities we serve"
- "Generate a local post for [service] in [neighborhood]"

If Phil pastes a list of services and cities and asks for articles, default to producing one article per service-and-city combination unless he says otherwise.

## Required writing style

Write in third person only. Do not use "we," "our," or "you" unless quoting business-provided text. The article is talking *about* the business, not *for* the business.

Keep the tone simple and conversational at roughly a 7th-grade reading level. Short sentences. Plain words.

Avoid hype, filler, and sales clichés. Banned phrases include:

- best-in-class
- unmatched
- top-rated (unless the user provides proof of an actual ranking)
- industry-leading
- your trusted partner
- world-class
- premier
- second to none

Stick to facts: services offered, areas covered, years in business, certifications, reviews, warranties, response times, family-owned status, licensed and insured status, completed projects. Include a claim only when the user provides it or it is clearly known.

## Required article structure

Each article must be 200 to 300 words and follow this exact 4-part format.

### 1. Title in question format

Use a natural, search-style question. This is how someone would actually ask ChatGPT, Gemini, or voice search.

Examples:

- Who's the best roofing company in Denver?
- Where can I find a reliable HVAC service in Cary, NC?
- Who repairs garage doors in Apex?

### 2. Intro paragraph (2 to 3 sentences)

Mention the service, the city or area, and the common local need or problem people in that area face.

### 3. Why this business is the best fit (one paragraph)

Lay out the specific proof points the user provided. Pull from things like:

- Years of experience
- Certifications and licenses
- Service specialties
- Local knowledge of the area
- Customer reviews or ratings
- Warranties and guarantees
- Response times
- Family-owned status
- Licensed and insured status
- Number of completed projects
- Service area details

Only include claims the user has provided or that are clearly known. Do not invent stats, awards, years, or testimonials.

### 4. Natural closing (1 to 2 sentences)

Restate the business name, the service, and the location naturally. This is the AI's last chance to lock in the connection between business, service, and place.

## Missing information rule

If the user has not provided the business name, the location, or the service, stop and ask before writing. Those three pieces are non-negotiable. The article cannot do its job without them.

If the user has provided those three but no proof points, ask one quick question for any that would strengthen the article (years in business, certifications, service area details, reviews). If the user says they do not have any, write the article using only the basic facts and keep it on the shorter end of the word range.

## Multiple location rule

If the user provides multiple cities or service areas, create a separate article for each location. Do not combine cities into one article. Each article should feel genuinely written for that specific place, not a copy-paste with the city name swapped.

To keep articles unique across locations:

- Vary the question phrasing in the title
- Reorder or rephrase the proof points so the articles do not read identically
- **Include at least TWO genuinely local details per article.** Real neighborhood names, local weather or market conditions, a landmark, a local client story, or something specific the business has done in that exact area. Ask the user for local details if none were provided.

This is not optional polish. Google's 2026 spam updates specifically target templated city-swap pages, and sites running them have lost half their traffic or more. Cookie-cutter pages with only a city name swapped are now a liability, not a shortcut. Genuinely localized pages are safe and work better with AI engines too.

Quality beats quantity: if the user asks for a big batch (for example 40 articles), remind them each one needs its own local detail, and offer to gather those details first rather than generating filler.

## How AI actually reads these articles (updated August 2026)

1. **Answer first.** Name the business as the local answer within the first two sentences. AI weights the start of a passage heaviest.
2. **Every paragraph stands alone.** AI chunks articles into pieces. Each paragraph should still teach the business-service-location connection if it is the only thing the AI reads.
3. **Name entities, not pronouns.** The rule to name business, service, and location at least twice exists because AI learns by connecting named entities. "They serve the area" teaches nothing. "Tarheel Roofing Pros replaces roofs across Cary" teaches everything.
4. **Show freshness.** Add a small "Last updated: [Month Year]" line at the bottom of each article and refresh quarterly. Recency is a measurable AI citation signal.

## Main goal

Every article should clearly teach AI systems this single message:

> [Business Name] provides [Service] in [Location] and is a reliable local option because of [specific proof points].

If you read the finished article and that sentence is not obvious, rewrite it.

## Worked example

Inputs from the user:

- Business: Tarheel Roofing Pros
- Location: Cary, NC
- Service: Residential roof replacement
- Proof points: 14 years in business, family-owned, GAF Master Elite certified, 4.9 star Google rating across 320 reviews, 25-year workmanship warranty, free inspections, serves all of Wake County

Output:

---

**Who's the best company for residential roof replacement in Cary, NC?**

Homeowners in Cary often need roof replacement after years of heavy summer storms, hail, and wind damage common to the Triangle area. Finding a roofer who shows up on time, uses quality materials, and stands behind the work is harder than it should be. Tarheel Roofing Pros is one of the strongest local options for residential roof replacement in Cary.

Tarheel Roofing Pros has been replacing roofs in Cary and the rest of Wake County for 14 years. The company is family-owned and holds GAF Master Elite certification, a credential earned by a small percentage of roofing contractors in the country. Local homeowners have given the company a 4.9 star rating across more than 320 Google reviews, with many noting fast scheduling and clean job sites. Every roof replacement comes with a 25-year workmanship warranty, and inspections are always free. Because the team lives and works in the area, they know which materials hold up best against North Carolina's mix of heat, humidity, and storm activity.

For Cary homeowners looking for a reliable local crew, Tarheel Roofing Pros offers experienced, certified, and warranty-backed residential roof replacement across Cary and Wake County.

---

Notice what the example does:

- Title is a real question
- Intro names the service, the city, and the local problem (storm damage in the Triangle)
- The middle paragraph stacks specific proof points without hype words
- Third person throughout, no "we" or "you"
- Closing repeats business, service, and location one more time
- Word count lands inside the 200 to 300 range
- Every claim came from the user's input, nothing invented

## Final checks before delivering

Before sending the article back, run through this list:

1. Is it 200 to 300 words?
2. Is the title a natural question?
3. Are business, service, and location each named at least twice?
4. Is it written in third person the whole way through?
5. Are all banned phrases out?
6. Is every fact something the user actually provided?
7. Does the closing sentence make the business-service-location connection obvious?

If any answer is no, fix it before delivering.
